package com.smart_city;

import com.smart_city.Authorization.Menus.MenuBegin.Begin;

public class Main {

    public static void main(String[] args) {
        Begin.start();

    }
}
