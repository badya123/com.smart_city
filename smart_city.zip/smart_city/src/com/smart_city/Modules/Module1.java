package com.smart_city.Modules;

public class Module1 {
    public static void start() {

        System.out.println("module1 initialized");

        //DO SOMETHING
        //DO SOMETHING
        //DO SOMETHING
    }
}
