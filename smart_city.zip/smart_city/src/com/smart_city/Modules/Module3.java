package com.smart_city.Modules;

public class Module3 {
    public static void start() {

        System.out.println("module3 initialized");

        //DO SOMETHING
        //DO SOMETHING
        //DO SOMETHING
    }
}
