package com.smart_city.Modules;

public class Module2 {
    public static void start() {

        System.out.println("module2 initialized");

        //DO SOMETHING
        //DO SOMETHING
        //DO SOMETHING
    }
}
